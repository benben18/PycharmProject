question=[]
repeat=[]
import re
for i in range(1,13):
    document_path='/home/transwarp/QA_search_TFID/data_process/searchtxt/'+str(i)+'.txt'
    with open(document_path,encoding='utf-8') as f:
        document = f.read()
        document_s=document.split('\n')
        for text in document_s:
            text_s=text.split('=')
            text_q=text_s[0]
            a='解答:'
            b='问题:'
            if a in text_q:
                text_q=text_q.replace(text_q,'')
            if b in text_q:
                text_q=re.sub(b,'',text_q)
            if text_q not in question:
                question.append(text_q)
            else:
                repeat.append(text_q)
print(len(question))
print(len(repeat))
with open('segement_clean.txt', 'w') as f2:
    for i in range(len(question)):
        f2.write(question[i]+'\n')

