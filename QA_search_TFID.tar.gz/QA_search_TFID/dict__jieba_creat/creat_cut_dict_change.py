import re
dict_path='dict_new.txt'
with open(dict_path,encoding='utf-8') as f:
    dict=f.read().lower().split('\n')
    software_name=[]
    for dic in dict:
        patten=re.compile(r'[A-Za-z]+')
        s_name=patten.findall(dic)
        if s_name not in software_name:
            software_name.append(s_name)
    for word in software_name:
        for i in range(1,10):
            for j in range(0,10):
                for k in range(0,10):
                    with open('dict_change_all.text','a',encoding='utf-8') as f1:
                        # f1.write(word[0]+str(i)+'.'+str(j)+'\n')
                        f1.write(word[0]+str(i)+'.'+str(j)+'.'+str(k)+'\n')
    for word in software_name:
        for i in range(1,10):
            for j in range(0,10):
                # for k in range(1,10):
                with open('dict_change_all.text','a',encoding='utf-8') as f1:
                    f1.write(word[0]+str(i)+'.'+str(j)+'\n')