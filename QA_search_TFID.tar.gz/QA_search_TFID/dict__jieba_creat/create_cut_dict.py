import re

document_path='/home/transwarp/PycharmProjects/search/segement.txt'

'''利用正则匹配的方法去除文本中英文字符和数字之间的空格，
防止利用jieba分词将软件与版本号分开，
并将去除空格后的文档进行保存。'''
def dele_space_A_num(document_path):
    with open(document_path, encoding='utf-8') as f:
        document = f.read().lower()
        document = re.sub('[→（）` ~ % # | > &&／* + } \\\ $ '
                          '{_\'； ; [\\]'' < "   ,＇ / ?=：:？“”《》‘，。！·、]+', ' ', document)
        pattern = re.compile('([a-zA-Z]+)\s([0-9].)|(sophon).(web)')
        result = pattern.findall(document)
        newdoc = re.sub(pattern, r'\1\2\3\4', document)


    with open('doc_new.txt', 'w', encoding='utf-8', ) as f2:
        f2.write(newdoc)
    return newdoc

'''只选择带有版本号的数据建立字典，过滤掉不是版本信息的字符'''
def select_dictdata(result):
    dict_ = []
    for tex in result:
        a = '.'
        if a in tex:
            dict_.append(tex)
    return dict_


'匹配文档中所有的专业术语加版本信息，建立分词词典'
def match_dict(document_path):
    newdoc=dele_space_A_num(document_path)
    newdoc=re.sub('\n',' ',newdoc)
    pattern1 = re.compile(r'[a-zA-Z]+[0-9].[0-9].[0-9]')  # 查找数字
    result1 = pattern1.findall(newdoc)
    dict1=select_dictdata(result1)

    pattern2 = re.compile(r'[a-zA-Z]+[0-9].[0-9]')
    result2 = pattern2.findall(newdoc)
    dict2=select_dictdata(result2)

    # pattern3 = re.compile(r'[a-zA-Z]+-[a-zA-Z]+')
    # dict3 = pattern3.findall(newdoc)
    # dict3=select_dictdata(result3)

    # pattern4 = re.compile(r'[a-zA-Z]+\.[a-zA-Z]+\(\)')
    # dict4 = pattern4.findall(newdoc)

    # pattern5 = re.compile(r'[a-zA-Z]+\(\)')
    # dict5 = pattern5.findall(newdoc)

    return dict1,dict2

'保存字典'
def to_dict(result1,result2):
    result_=[result1,result2]
    result=[]
    for i in range(0,2):
        for resul in result_[i]:
            result.append(resul)
    print(len(result))
    result_dict='\n'.join(result)

    with open('dict_new.txt','w',encoding='utf-8',) as f1:
        f1.write(result_dict)


dict1,dict2=match_dict(document_path)
print(len(dict1)+len(dict2))
to_dict(dict1,dict2)
