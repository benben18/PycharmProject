
import jieba.analyse
import re

document_path = '/home/transwarp/QA_search_TFID/dict__jieba_creat/doc_new.txt'
with open(document_path, encoding='utf-8') as f:
    document = f.read()
    document= re.sub('\n', ' ', document)
    jieba.load_userdict("/home/transwarp/QA_search_TFID/dict__jieba_creat/dict_new.txt")
    document_cut = jieba.cut(document)  # 结巴分词
    result = '\n'.join(document_cut)
    with open('/home/transwarp/QA_search_TFID/dict__jieba_creat/jieba_cut.txt', 'w',encoding='utf-8') as f2:
        f2.write(result)







