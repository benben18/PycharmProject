# -- encoding:utf-8 --
"""
Create by on 2019/3/30
根据tfidf模型的相似度
"""
import jieba
from gensim import corpora, models, similarities
import re


# 1.jieba 去特殊字符、分词
# 2.dictionary
# 3.tfidf
# 4.similarity

def word_cut(sentence,dict_path):
    jieba.load_userdict(dict_path)
    # print('loading jieba dict')
    sentence_cut = list(jieba.cut(sentence))  # 结巴分词
    return sentence_cut


def document_cut(document_path,dict_path):
    with open(document_path, encoding='utf-8') as f:
        document = f.read().lower()
        document = re.sub('[→（）` ~ % # | > &&／* + } \-\\\ $ '
                          '{_\'； ; [\\]'' < " ,＇() / ?=：:？“”《》‘，。！·、]+', ' ', document)


        pattern = re.compile('([a-zA-Z]+)\s([0-9].|(sophon).(web))')
        result = pattern.findall(document)
        newdoc = re.sub(pattern, r'\1\2\3\4', document)
        document=newdoc.split('\n')
        doc_cut = []
        for sent in document:
            sentence_cut = word_cut(sent,dict_path)  # 结巴分词
            doc_cut.append(sentence_cut)
    return doc_cut


# 2.dictionary
def creat_dict(doc_cut):
    dictionary = corpora.Dictionary(doc_cut)  # 统计有多少个为重复的词，并进行编号
    corpus = [dictionary.doc2bow(sentence) for sentence in doc_cut]

    return dictionary, corpus
def main_similarity(document_path, doc_test,dict_path):

    doc_cut = document_cut(document_path,dict_path)#分词
    dictionary, corpus = creat_dict(doc_cut)#利用字典向量化文档


    tfidf = models.TfidfModel(corpus)


    index = similarities.SparseMatrixSimilarity(tfidf[corpus], num_features=len(dictionary.keys()))



    doc_test=doc_test.lower()
    patten_0=re.compile(r'([a-zA-Z]+)\s([0-9].[0-9])|([a-zA-Z]+)\s([0-9].[0-9].[0-9])')
    res=patten_0.findall(doc_test)
    if res:
        # print('合并空格')
        doc_test=re.sub(patten_0,r'\1\2\3\4',doc_test)
    document_cut_test = word_cut(doc_test,dict_path)  # 结巴分词
    doc_test_vec = dictionary.doc2bow(document_cut_test)


    sim = index[tfidf[doc_test_vec]]
    sim_result = sorted(enumerate(sim), key=lambda item: -item[1])
    data_sim = []
    with open(document_path, encoding='utf-8') as f:
        document = f.read().split('\n')
        if sim_result[0][1] == 0.0:
            print('对不起，没有找到相关的问题，换一个关键词试试。')
        else:
            for i in range(0, 10):
                index_sim = sim_result[i][0]
                data_sim.append([document[index_sim],sim_result[i][1]])
            print(data_sim)


doc_test = 'SopHon 2.5'

dict_path="/home/transwarp/QA_search_TFID/TFIDF_Q_similarity/dict_new.txt"
document_path='/home/transwarp/QA_search_TFID/data_process/segement_clean.txt'

main_similarity(document_path, doc_test,dict_path)

